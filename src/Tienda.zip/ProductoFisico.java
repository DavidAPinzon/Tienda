public class ProductoFisico extends Producto {
    private double precioBase;
    private double costoEnvio;

    public ProductoFisico(String nombre, int id, double precioBase, double costoEnvio){
        super(nombre, id);
        this.precioBase = precioBase;
        this.costoEnvio = costoEnvio;
    }

    @Override
    public double calcularPrecioTotal() {
        return precioBase + costoEnvio;
    }

    @Override
    public void mostrarInformarcion() {
        System.out.println("Producto Fisico: " + nombre);
        System.out.println("ID: " + id);
        System.out.println("Precio Base: " + precioBase);
        System.out.println("Costo Envio: " + costoEnvio);
    }

    @Override
    public void mostrarInformacion() {

    }
}
