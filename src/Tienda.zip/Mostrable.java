public interface Mostrable {
    void mostrarInformacion();
}
