public interface Calculable {
    double calcularPrecioTotal();
}
