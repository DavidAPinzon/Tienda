import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese el Tipo de Producto (Fisico, Digital, Servicio)");
        String tipoProducto = scanner.nextLine();

        Producto producto = null;

        switch (tipoProducto.toLowerCase()) {
            case "Fisico":
                producto = new ProductoFisico("Laptop", 1, 1200.0, 50.0);
                break;
            case "Digital":
                producto = new ProductoDigital("Software", 2, 80.0);
                break;
            case "Servicio":
                producto = new Servicio("Consultoria", 3, 10, 100.0);
                break;
            default:
                System.out.println("Tipo de Producto Invalido");
        }

        if (producto != null) {
            producto.mostrarInformacion();
            System.out.println("Precio Total: " + producto.calcularPrecioTotal());
        }

        scanner.close();
    }
}